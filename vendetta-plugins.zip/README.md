# horror plugins

- [customVoiceMessages](https://dziurwa14.github.io/vendetta-plugins/customVoiceMessages)

## How to install?

Paste a plugin URL into the Plugins page of Vendetta
